import json
import random
import shutil
from pathlib import Path
from collections import Counter

import cv2


# ============================================================
# 1. 기본 경로 설정
# ============================================================

# 현재 split_dataset.py가 위치한 폴더
BASE_DIR = Path(__file__).resolve().parent

# JPG + JSON이 모두 들어있는 원본 폴더
INPUT_DIR = BASE_DIR / "dataset"

# 변환된 YOLO 데이터셋이 저장될 폴더
OUTPUT_DIR = BASE_DIR / "yolo_dataset"

# YOLO 학습용 yaml 파일
YAML_PATH = BASE_DIR / "dataset.yaml"


# ============================================================
# 2. 클래스 설정
#
# YOLO는 0번부터 시작
#
# 0 = red_light
# 1 = yellow_light
# 2 = green_light
# 3 = left_light
# ============================================================

CLASSES = [
    "red_light",
    "yellow_light",
    "green_light",
    "left_light",
]


# ============================================================
# 3. Train / Validation / Test 비율
# ============================================================

TRAIN_RATIO = 0.80
VAL_RATIO = 0.10
TEST_RATIO = 0.10


# ============================================================
# 4. 랜덤 설정
#
# 같은 seed를 사용하면
# 실행할 때마다 동일한 랜덤 분할 결과가 나옴
#
# 논문 실험에서는 고정하는 것을 권장
# ============================================================

RANDOM_SEED = 42


# ============================================================
# 5. 지원 이미지 확장자
# ============================================================

IMAGE_EXTENSIONS = {
    ".jpg",
    ".jpeg",
    ".png",
    ".bmp",
    ".webp",
}


# ============================================================
# 이미지 크기 확인
# ============================================================

def get_image_size(image_path, json_data):
    """
    LabelMe JSON의 imageWidth/imageHeight를 먼저 사용하고,
    없으면 OpenCV로 실제 이미지 크기를 읽는다.
    """

    image_width = json_data.get("imageWidth")
    image_height = json_data.get("imageHeight")

    # JSON 안에 정상적으로 크기가 들어있으면 사용
    if image_width and image_height:

        return (
            int(image_width),
            int(image_height),
        )

    # JSON에 없다면 실제 JPG 파일 읽기
    image = cv2.imread(str(image_path))

    if image is None:
        raise ValueError(
            f"이미지를 읽을 수 없습니다: {image_path}"
        )

    image_height, image_width = image.shape[:2]

    return (
        image_width,
        image_height,
    )


# ============================================================
# LabelMe JSON → YOLO TXT 변환
# ============================================================

def convert_labelme_to_yolo(
    image_path,
    json_path,
    output_txt_path,
    class_to_id,
):
    """
    LabelMe JSON의 Bounding Box를
    YOLO Detection TXT 형식으로 변환한다.

    YOLO TXT:
        class_id x_center y_center width height

    모든 좌표는 0~1 범위로 정규화된다.
    """

    # --------------------------------------------------------
    # JSON 읽기
    # --------------------------------------------------------

    with open(
        json_path,
        "r",
        encoding="utf-8",
    ) as f:

        data = json.load(f)

    # --------------------------------------------------------
    # 이미지 크기
    # --------------------------------------------------------

    image_width, image_height = get_image_size(
        image_path,
        data,
    )

    yolo_lines = []

    unknown_labels = []

    invalid_boxes = 0

    shapes = data.get("shapes", [])

    # --------------------------------------------------------
    # JSON 안의 모든 라벨 처리
    # --------------------------------------------------------

    for shape in shapes:

        label = (
            shape.get("label", "")
            .strip()
        )

        # 빈 라벨이면 무시
        if not label:
            continue

        # ----------------------------------------------------
        # 우리가 지정한 클래스가 아닌 경우
        # ----------------------------------------------------

        if label not in class_to_id:

            unknown_labels.append(label)

            continue

        points = shape.get("points", [])

        # Bounding Box를 만들려면 최소 2개 좌표 필요
        if len(points) < 2:

            invalid_boxes += 1

            continue

        # ----------------------------------------------------
        # 좌표 추출
        #
        # LabelMe rectangle:
        #
        # [
        #     [x1, y1],
        #     [x2, y2]
        # ]
        #
        # polygon으로 저장되어 있어도
        # min/max를 사용해서 Bounding Box로 변환 가능
        # ----------------------------------------------------

        xs = [
            float(point[0])
            for point in points
        ]

        ys = [
            float(point[1])
            for point in points
        ]

        x_min = min(xs)
        x_max = max(xs)

        y_min = min(ys)
        y_max = max(ys)

        # ----------------------------------------------------
        # 이미지 영역 밖 좌표 보정
        # ----------------------------------------------------

        x_min = max(
            0.0,
            min(
                x_min,
                float(image_width),
            ),
        )

        x_max = max(
            0.0,
            min(
                x_max,
                float(image_width),
            ),
        )

        y_min = max(
            0.0,
            min(
                y_min,
                float(image_height),
            ),
        )

        y_max = max(
            0.0,
            min(
                y_max,
                float(image_height),
            ),
        )

        # ----------------------------------------------------
        # Bounding Box 크기
        # ----------------------------------------------------

        bbox_width = (
            x_max - x_min
        )

        bbox_height = (
            y_max - y_min
        )

        # 잘못된 Box 제거
        if (
            bbox_width <= 0
            or bbox_height <= 0
        ):

            invalid_boxes += 1

            continue

        # ----------------------------------------------------
        # 중심 좌표 계산
        # ----------------------------------------------------

        x_center = (
            x_min + x_max
        ) / 2.0

        y_center = (
            y_min + y_max
        ) / 2.0

        # ----------------------------------------------------
        # YOLO 좌표 정규화
        #
        # 픽셀 좌표
        # ↓
        # 0 ~ 1
        # ----------------------------------------------------

        x_center /= image_width
        y_center /= image_height

        bbox_width /= image_width
        bbox_height /= image_height

        # ----------------------------------------------------
        # 안전하게 0~1 범위로 제한
        # ----------------------------------------------------

        x_center = max(
            0.0,
            min(1.0, x_center),
        )

        y_center = max(
            0.0,
            min(1.0, y_center),
        )

        bbox_width = max(
            0.0,
            min(1.0, bbox_width),
        )

        bbox_height = max(
            0.0,
            min(1.0, bbox_height),
        )

        # ----------------------------------------------------
        # 클래스 번호
        # ----------------------------------------------------

        class_id = class_to_id[
            label
        ]

        # ----------------------------------------------------
        # YOLO TXT 한 줄
        # ----------------------------------------------------

        yolo_line = (
            f"{class_id} "
            f"{x_center:.6f} "
            f"{y_center:.6f} "
            f"{bbox_width:.6f} "
            f"{bbox_height:.6f}"
        )

        yolo_lines.append(
            yolo_line
        )

    # --------------------------------------------------------
    # YOLO TXT 저장
    # --------------------------------------------------------

    with open(
        output_txt_path,
        "w",
        encoding="utf-8",
    ) as f:

        f.write(
            "\n".join(yolo_lines)
        )

    return (
        len(yolo_lines),
        unknown_labels,
        invalid_boxes,
    )


# ============================================================
# YOLO 폴더 생성
# ============================================================

def create_output_directories():

    for split_name in [
        "train",
        "val",
        "test",
    ]:

        image_dir = (
            OUTPUT_DIR
            / "images"
            / split_name
        )

        label_dir = (
            OUTPUT_DIR
            / "labels"
            / split_name
        )

        image_dir.mkdir(
            parents=True,
            exist_ok=True,
        )

        label_dir.mkdir(
            parents=True,
            exist_ok=True,
        )


# ============================================================
# Train / Val / Test 각각 처리
# ============================================================

def process_split(
    pairs,
    split_name,
    class_to_id,
):

    image_output_dir = (
        OUTPUT_DIR
        / "images"
        / split_name
    )

    label_output_dir = (
        OUTPUT_DIR
        / "labels"
        / split_name
    )

    class_counter = Counter()

    unknown_counter = Counter()

    total_boxes = 0

    total_invalid_boxes = 0

    empty_label_files = 0

    # --------------------------------------------------------
    # 각각의 이미지 + JSON 처리
    # --------------------------------------------------------

    for index, (
        image_path,
        json_path,
    ) in enumerate(
        pairs,
        start=1,
    ):

        # ----------------------------------------------------
        # 이미지 복사
        # ----------------------------------------------------

        destination_image = (
            image_output_dir
            / image_path.name
        )

        shutil.copy2(
            image_path,
            destination_image,
        )

        # ----------------------------------------------------
        # YOLO TXT 저장 경로
        # ----------------------------------------------------

        destination_label = (
            label_output_dir
            / f"{image_path.stem}.txt"
        )

        # ----------------------------------------------------
        # LabelMe JSON → YOLO TXT
        # ----------------------------------------------------

        (
            box_count,
            unknown_labels,
            invalid_boxes,
        ) = convert_labelme_to_yolo(
            image_path=image_path,
            json_path=json_path,
            output_txt_path=destination_label,
            class_to_id=class_to_id,
        )

        total_boxes += (
            box_count
        )

        total_invalid_boxes += (
            invalid_boxes
        )

        # Box가 하나도 없다면 카운트
        if box_count == 0:

            empty_label_files += 1

        # ----------------------------------------------------
        # 정의되지 않은 클래스 통계
        # ----------------------------------------------------

        for unknown_label in unknown_labels:

            unknown_counter[
                unknown_label
            ] += 1

        # ----------------------------------------------------
        # 생성된 YOLO TXT 읽어서
        # 클래스별 Bounding Box 개수 계산
        # ----------------------------------------------------

        if destination_label.exists():

            with open(
                destination_label,
                "r",
                encoding="utf-8",
            ) as f:

                for line in f:

                    line = (
                        line.strip()
                    )

                    if not line:
                        continue

                    parts = (
                        line.split()
                    )

                    class_id = int(
                        parts[0]
                    )

                    class_counter[
                        class_id
                    ] += 1

        # ----------------------------------------------------
        # 진행 상황 표시
        # ----------------------------------------------------

        if (
            index % 100 == 0
            or index == len(pairs)
        ):

            print(
                f"  {split_name}: "
                f"{index}/{len(pairs)} 완료"
            )

    return {
        "class_counter": class_counter,
        "unknown_counter": unknown_counter,
        "total_boxes": total_boxes,
        "invalid_boxes": total_invalid_boxes,
        "empty_labels": empty_label_files,
    }


# ============================================================
# dataset.yaml 생성
# ============================================================

def create_dataset_yaml():

    with open(
        YAML_PATH,
        "w",
        encoding="utf-8",
    ) as f:

        # Docker 내부에서 프로젝트가
        # /workspace로 연결된다는 기준
        f.write(
            "path: /workspace/yolo_dataset\n\n"
        )

        f.write(
            "train: images/train\n"
        )

        f.write(
            "val: images/val\n"
        )

        f.write(
            "test: images/test\n\n"
        )

        f.write(
            "names:\n"
        )

        for (
            class_id,
            class_name,
        ) in enumerate(
            CLASSES
        ):

            f.write(
                f"  {class_id}: "
                f"{class_name}\n"
            )


# ============================================================
# 클래스 통계 출력
# ============================================================

def print_class_statistics(
    train_result,
    val_result,
    test_result,
):

    print()
    print("=" * 70)
    print("클래스별 Bounding Box 개수")
    print("=" * 70)

    for (
        class_id,
        class_name,
    ) in enumerate(
        CLASSES
    ):

        train_count = (
            train_result[
                "class_counter"
            ][class_id]
        )

        val_count = (
            val_result[
                "class_counter"
            ][class_id]
        )

        test_count = (
            test_result[
                "class_counter"
            ][class_id]
        )

        total_count = (
            train_count
            + val_count
            + test_count
        )

        print()

        print(
            f"[{class_id}] "
            f"{class_name}"
        )

        print(
            f"  Train : "
            f"{train_count}"
        )

        print(
            f"  Val   : "
            f"{val_count}"
        )

        print(
            f"  Test  : "
            f"{test_count}"
        )

        print(
            f"  Total : "
            f"{total_count}"
        )


# ============================================================
# Main
# ============================================================

def main():

    print()
    print("=" * 70)
    print(
        "LabelMe → YOLO Random Dataset Converter"
    )
    print("=" * 70)

    # ========================================================
    # 분할 비율 검사
    # ========================================================

    ratio_sum = (
        TRAIN_RATIO
        + VAL_RATIO
        + TEST_RATIO
    )

    if abs(
        ratio_sum - 1.0
    ) > 1e-6:

        print()
        print(
            "[오류] "
            "TRAIN_RATIO + VAL_RATIO + TEST_RATIO "
            "합이 1.0이어야 합니다."
        )

        return

    # ========================================================
    # 클래스 설정
    # ========================================================

    print()
    print("=" * 70)
    print("YOLO 클래스")
    print("=" * 70)

    for (
        class_id,
        class_name,
    ) in enumerate(
        CLASSES
    ):

        print(
            f"{class_id}: "
            f"{class_name}"
        )

    # 클래스 이름 → 번호
    class_to_id = {

        class_name: class_id

        for (
            class_id,
            class_name,
        ) in enumerate(
            CLASSES
        )
    }

    # ========================================================
    # Dataset 폴더 확인
    # ========================================================

    print()
    print(
        "원본 데이터:"
    )

    print(
        INPUT_DIR
    )

    if not INPUT_DIR.exists():

        print()
        print(
            "[오류] dataset 폴더를 "
            "찾을 수 없습니다."
        )

        return

    # ========================================================
    # 이미지 검색
    # ========================================================

    image_files = sorted(
        [
            path
            for path
            in INPUT_DIR.iterdir()

            if (
                path.is_file()
                and
                path.suffix.lower()
                in IMAGE_EXTENSIONS
            )
        ]
    )

    print()
    print(
        f"발견한 이미지: "
        f"{len(image_files)}장"
    )

    if not image_files:

        print(
            "[오류] 이미지 파일이 없습니다."
        )

        return

    # ========================================================
    # 이미지 + JSON 짝 찾기
    # ========================================================

    pairs = []

    missing_json = []

    for image_path in image_files:

        json_path = (
            image_path
            .with_suffix(".json")
        )

        if json_path.exists():

            pairs.append(
                (
                    image_path,
                    json_path,
                )
            )

        else:

            missing_json.append(
                image_path.name
            )

    print(
        f"정상 이미지 + JSON 쌍: "
        f"{len(pairs)}개"
    )

    # ========================================================
    # JSON 없는 이미지
    # ========================================================

    if missing_json:

        print()
        print(
            f"[경고] JSON이 없는 이미지: "
            f"{len(missing_json)}개"
        )

        for filename in (
            missing_json[:20]
        ):

            print(
                f"  {filename}"
            )

        if len(
            missing_json
        ) > 20:

            print(
                "  ..."
            )

    if not pairs:

        print()
        print(
            "[오류] 사용할 수 있는 "
            "이미지 + JSON 쌍이 없습니다."
        )

        return

    # ========================================================
    # 이미지 없는 JSON 검사
    # ========================================================

    image_stems = {
        image_path.stem
        for image_path
        in image_files
    }

    all_json_files = list(
        INPUT_DIR.glob(
            "*.json"
        )
    )

    json_without_image = [
        json_path
        for json_path
        in all_json_files

        if json_path.stem
        not in image_stems
    ]

    if json_without_image:

        print()
        print(
            f"[경고] 이미지가 없는 JSON: "
            f"{len(json_without_image)}개"
        )

        for json_path in (
            json_without_image[:20]
        ):

            print(
                f"  {json_path.name}"
            )

    # ========================================================
    # ★ 완전 랜덤 Shuffle
    # ========================================================

    random_generator = (
        random.Random(
            RANDOM_SEED
        )
    )

    random_generator.shuffle(
        pairs
    )

    total_count = len(
        pairs
    )

    # ========================================================
    # 데이터 개수 계산
    # ========================================================

    train_count = int(
        total_count
        * TRAIN_RATIO
    )

    val_count = int(
        total_count
        * VAL_RATIO
    )

    # 남은 것은 전부 Test
    test_count = (
        total_count
        - train_count
        - val_count
    )

    # ========================================================
    # Random Shuffle 된 결과에서 분할
    # ========================================================

    train_pairs = (
        pairs[
            :train_count
        ]
    )

    val_pairs = (
        pairs[
            train_count:
            train_count + val_count
        ]
    )

    test_pairs = (
        pairs[
            train_count + val_count:
        ]
    )

    # ========================================================
    # 분할 결과 출력
    # ========================================================

    print()
    print("=" * 70)
    print("랜덤 데이터 분할 결과")
    print("=" * 70)

    print(
        f"Random Seed : "
        f"{RANDOM_SEED}"
    )

    print()

    print(
        f"전체  : "
        f"{total_count}"
    )

    print(
        f"Train : "
        f"{len(train_pairs)} "
        f"({len(train_pairs) / total_count * 100:.2f}%)"
    )

    print(
        f"Val   : "
        f"{len(val_pairs)} "
        f"({len(val_pairs) / total_count * 100:.2f}%)"
    )

    print(
        f"Test  : "
        f"{len(test_pairs)} "
        f"({len(test_pairs) / total_count * 100:.2f}%)"
    )

    # ========================================================
    # 기존 yolo_dataset 삭제
    # ========================================================

    if OUTPUT_DIR.exists():

        print()
        print(
            "기존 yolo_dataset "
            "폴더를 삭제합니다..."
        )

        shutil.rmtree(
            OUTPUT_DIR
        )

    # ========================================================
    # 새로운 YOLO 폴더 생성
    # ========================================================

    create_output_directories()

    # ========================================================
    # Train 변환
    # ========================================================

    print()
    print("=" * 70)
    print("TRAIN 데이터 변환")
    print("=" * 70)

    train_result = process_split(
        pairs=train_pairs,
        split_name="train",
        class_to_id=class_to_id,
    )

    # ========================================================
    # Validation 변환
    # ========================================================

    print()
    print("=" * 70)
    print("VALIDATION 데이터 변환")
    print("=" * 70)

    val_result = process_split(
        pairs=val_pairs,
        split_name="val",
        class_to_id=class_to_id,
    )

    # ========================================================
    # Test 변환
    # ========================================================

    print()
    print("=" * 70)
    print("TEST 데이터 변환")
    print("=" * 70)

    test_result = process_split(
        pairs=test_pairs,
        split_name="test",
        class_to_id=class_to_id,
    )

    # ========================================================
    # dataset.yaml 생성
    # ========================================================

    create_dataset_yaml()

    # ========================================================
    # 클래스 통계
    # ========================================================

    print_class_statistics(
        train_result,
        val_result,
        test_result,
    )

    # ========================================================
    # 전체 Bounding Box 통계
    # ========================================================

    total_boxes = (
        train_result[
            "total_boxes"
        ]
        + val_result[
            "total_boxes"
        ]
        + test_result[
            "total_boxes"
        ]
    )

    print()
    print("=" * 70)
    print("Bounding Box 통계")
    print("=" * 70)

    print(
        f"Train Box : "
        f"{train_result['total_boxes']}"
    )

    print(
        f"Val Box   : "
        f"{val_result['total_boxes']}"
    )

    print(
        f"Test Box  : "
        f"{test_result['total_boxes']}"
    )

    print(
        f"Total Box : "
        f"{total_boxes}"
    )

    # ========================================================
    # 빈 라벨 검사
    # ========================================================

    total_empty_labels = (
        train_result[
            "empty_labels"
        ]
        + val_result[
            "empty_labels"
        ]
        + test_result[
            "empty_labels"
        ]
    )

    if total_empty_labels > 0:

        print()
        print(
            f"[경고] Bounding Box가 없는 이미지: "
            f"{total_empty_labels}장"
        )

    # ========================================================
    # 잘못된 Bounding Box
    # ========================================================

    total_invalid_boxes = (
        train_result[
            "invalid_boxes"
        ]
        + val_result[
            "invalid_boxes"
        ]
        + test_result[
            "invalid_boxes"
        ]
    )

    if total_invalid_boxes > 0:

        print()
        print(
            f"[경고] 잘못되어 제외된 Box: "
            f"{total_invalid_boxes}개"
        )

    # ========================================================
    # labels에 없는 클래스 확인
    # ========================================================

    total_unknown = Counter()

    total_unknown.update(
        train_result[
            "unknown_counter"
        ]
    )

    total_unknown.update(
        val_result[
            "unknown_counter"
        ]
    )

    total_unknown.update(
        test_result[
            "unknown_counter"
        ]
    )

    if total_unknown:

        print()
        print("=" * 70)
        print(
            "[경고] CLASSES에 없는 라벨 발견"
        )
        print("=" * 70)

        for (
            label,
            count,
        ) in total_unknown.items():

            print(
                f"{label}: "
                f"{count}개"
            )

        print()
        print(
            "위 라벨들은 YOLO 학습 데이터에서 "
            "제외되었습니다."
        )

    # ========================================================
    # 완료
    # ========================================================

    print()
    print("=" * 70)
    print("변환 완료!")
    print("=" * 70)

    print()

    print(
        "YOLO Dataset:"
    )

    print(
        OUTPUT_DIR
    )

    print()

    print(
        "dataset.yaml:"
    )

    print(
        YAML_PATH
    )

    print()

    print(
        "최종 클래스:"
    )

    for (
        class_id,
        class_name,
    ) in enumerate(
        CLASSES
    ):

        print(
            f"  {class_id} = "
            f"{class_name}"
        )

    print()
    print(
        "이제 YOLO 학습에 사용할 수 있습니다."
    )


# ============================================================
# 실행
# ============================================================

if __name__ == "__main__":
    main()